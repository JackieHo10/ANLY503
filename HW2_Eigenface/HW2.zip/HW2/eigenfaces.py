# -*- coding: utf-8 -*-
"""
Created on Tue Nov 13 13:52:39 2018

@author: jacky
"""
## HW2 ##

##import libraries 
import os
import sys
import bisect
import numpy as np
from PIL import Image

##convert an image to a vector
fullpath = r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\FACESdata\s1\1.pgm" #row string input
img1 = Image.open(fullpath).convert('L')
img1.show()
img1.save(r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\FaceInput.jpg") 
imagearray1 = np.array(img1) 
original_shape = imagearray1.shape
flat1 = imagearray1.ravel() #return a 1D array containing the elements of the input
facevector1 = np.matrix(flat1)
facematrix = facevector1
print(facematrix.shape)
shape = flat1.shape
print(shape)
#define a helper function
def ImageToVector(path):
    img = Image.open(path).convert('L')
    vec = np.array(img, dtype = np.uint8).ravel()
    return vec

##place all vectorized images into a matrix
def All_ImageToVector(filedir):
    for subdir, dirs, files in os.walk(filedir):
        for file in files:
            path = os.fsdecode((os.path.join(subdir, file)))
            if path.endswith(".pgm"):
                image_vect = ImageToVector(path)
                yield image_vect
all_face_matrix = np.column_stack(All_ImageToVector(os.fsencode(r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\FACESdata")))
print("the face matrix is: \n")
print(all_face_matrix)
print(all_face_matrix.shape)

##convert a vector to an image
face_example = np.asarray(all_face_matrix[:, 0]).astype(np.uint8).reshape(original_shape)
#make a PIL image and then save as JPEG
face_example_img = Image.fromarray(face_example, 'L')
face_example_img.show()
face_example_img.save(r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\FaceOutput.jpg")

##create a normalized face matrix and save the mean face to JPEG
column_means = np.mean(all_face_matrix, axis = 1).astype(np.uint8)
mean_image = Image.fromarray(column_means.reshape(original_shape), 'L')
mean_image.show()
mean_image.save(r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\meanface.jpg")
norm_face_matrix = all_face_matrix.astype(np.int16) - column_means[:, None]
print("the normalized matrix is: \n")
print(norm_face_matrix)
print(norm_face_matrix.shape)
#write the output into a doc file
#with open('eigen.doc', 'w') as f: 
#    f.write(str(norm_face_matrix))

##Turk and Pentland method for PCA
CovMatrix = np.cov(norm_face_matrix.T)
print("the covariance matrix is: \n")
print(CovMatrix)
print(CovMatrix.shape)
e_vals, e_vecs = np.linalg.eig(CovMatrix)
print("Eigenvalues: \n", e_vals)
print("Eigenvectors: \n", e_vecs)
#order the eigenvalues and get the eigenvectors
idx = e_vals.argsort()[::-1] #sorting in descending order
e_vals = e_vals[idx]
e_vecs = e_vecs[:, idx]
print("Sorted Eigenvalues: \n", e_vals)
print("Sorted Eigenvectors: \n", e_vecs)
#choose the top k eigenvalues and eigenvectors
k = int(input("Please enter the value of k! (must be an integer less than 400)\n"))
if k >= 400 or k <= 0:
    sys.exit("Error: invalid k") #check errors
e_vals = e_vals[0:k]
e_vecs = e_vecs[0:k]
print(e_vals)
print(e_vecs)
#write the output into a doc file
with open('eigen.doc', 'w') as f: 
    f.write(str(norm_face_matrix) + "\n")
    f.write(str(e_vals) + "\n")
    f.write(str(e_vecs) + "\n")
#project the k eigenvectors back into the original space
e_matrix = np.dot(norm_face_matrix, e_vecs.T)
print("the eigenface matrix is: \n")
print(e_matrix)
print(e_matrix.shape)
#convert all of the eigenfaces into images and save them as JPEG files
for i in range(k):
    egface_example = np.asarray(e_matrix.T[i]).astype(np.uint8).reshape(original_shape)
    egface_example_img = Image.fromarray(egface_example, 'L')
    egface_example_img.show()
    egface_example_img.save(r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\eigenface_" + str(i + 1) + ".jpg")

##Test 1
#define a couple of helper functions
def Get_Ematrix(image_vect):
    norm_image_vect = image_vect - column_means
    Ematrix = np.dot(e_matrix.T, norm_image_vect)
    return Ematrix
def EuclideanDistance(u, v):
    dist = np.linalg.norm(u - v)
    return dist
def Similarity(image_vect):
    results = []
    scores = []
    pj_image_vect = Get_Ematrix(image_vect)
    for v in all_face_matrix.T:
        pj_v = Get_Ematrix(v)
        score = EuclideanDistance(pj_image_vect, pj_v)
        insert_idx = bisect.bisect(scores, score)
        scores.insert(insert_idx, score)
        results.insert(insert_idx, (v, score))
    return results
#test it below
test_path = r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\TEST_Image.pgm"
img_test = Image.open(test_path).convert('L') 
img_test.show()
img_test.save(r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\TEST_Image.jpg")
test_vec = ImageToVector(test_path)
print(test_vec)
print(Similarity(test_vec))
img_test_1 = Image.fromarray(Similarity(test_vec)[0][0].astype(np.uint8).reshape(original_shape), 'L')
img_test_1.show()
img_test_1.save(r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\PREDICTED_Image.jpg")

##Test 2 (Notice that the dataset has been modified! Run this part separately!)
img_test_2 = Image.fromarray(Similarity(test_vec)[1][0].astype(np.uint8).reshape(original_shape), 'L')
img_test_2.show()
img_test_2.save(r"C:\Users\jacky\Desktop\HW\ANLY503\HW2\PREDICTED_Image.jpg")































































